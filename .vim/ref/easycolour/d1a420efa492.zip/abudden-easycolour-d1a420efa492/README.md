# EasyColour

This plugin makes it really easy to create your own colour scheme for Vim.  You don't need to understand the syntax of Vim script and if you want to base your colour scheme on an existing one, you can!

There's more information available on the website:

  [http://www.cgtk.co.uk/vim-scripts/easycolour][Website]

The source is managed in Mercurial and is available on [bitbucket][Bitbucket].

Detailed documentation can be found in [doc/EasyColour.txt][Documentation].

[Website]: http://www.cgtk.co.uk/vim-scripts/easycolour
[Bitbucket]: https://bitbucket.org/abudden/easycolour
[Documentation]: https://bitbucket.org/abudden/easycolour/src/default/doc/EasyColour.txt
